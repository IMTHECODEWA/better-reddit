# Project Name

Describe your project here.

## Structure

- `src/` – Source code
- `tests/` – Unit and integration tests
- `docs/` – Documentation (guides, architecture, etc.)
- `.gitignore` – Files and folders git should ignore
- `LICENSE` – Project license